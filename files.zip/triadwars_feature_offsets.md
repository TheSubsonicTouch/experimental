# Triad Wars offset map for the Sleeping Dogs mod menu

Offsets are RVAs (add the module base). `SD` = sdhdship.exe (Sleeping Dogs DE), `TW` = TriadWars.exe.

Confidence: **A** = byte-identical function, unique match. **B** = same function with small edits, call targets and strings agree. **C** = positional + similarity only (probable, verify). **X** = not found.

None of this was tested at runtime. Function matching shows the code exists at the new address, not that struct field offsets or argument layouts are unchanged.


## God mode / health / teleport-to-vehicle

Game functions: 36 (A:13 B:7 C:4 X:12). Data globals: 11 (10 resolved).

| SD fn | TW fn | conf | note |
|---|---|---|---|
| 0x1810 | - | X | unresolved |
| 0x2080 | 0x3f20 | B | similar (0.99) calls 1.00 str 1.00 |
| 0x6ee30 | 0x75c70 | B | similar (1.00) calls 1.00 str 0.00 |
| 0x170b80 | 0x1a8010 | A | identical bytes (unique) |
| 0x18b720 | 0x1c3230 | A | identical bytes (unique) |
| 0x1905c0 | - | X | unresolved |
| 0x190a50 | 0x1c8a60 | A | identical bytes (unique) |
| 0x190ad0 | 0x1c8ae0 | A | identical bytes (unique) |
| 0x190c40 | 0x1c8c50 | A | identical bytes (unique) |
| 0x1b65c0 | 0x1f03c0 | A | identical bytes (unique) |
| 0x1b6890 | 0x1f0690 | A | identical bytes (unique) |
| 0x1b9390 | 0x1f3890 | A | identical bytes (unique) |
| 0x1e9ef0 | - | X | unresolved |
| 0x1e9ff0 | - | X | unresolved |
| 0x1f75f0 | - | X | unresolved |
| 0x236a50 | - | X | unresolved |
| 0x270140 | 0x2a0130 | C | positional+similarity 1.00 (runner-up 0.47) |
| 0x272e40 | - | X | unresolved |
| 0x3a0be0 | 0x3d7ee0 | A | identical bytes (unique) |
| 0x3ae110 | 0x3e5670 | A | identical bytes (unique) |
| 0x3f03c0 | 0x42b9d0 | B | similar (1.00) calls 1.00 str 0.00 |
| 0x3f0550 | 0x42bbb0 | C | positional+similarity 1.00 (runner-up 0.46) |
| 0x43f280 | 0x4c81d0 | C | positional+similarity 0.96 (runner-up 0.50) |
| 0x43fbe0 | - | X | unresolved |
| 0x441910 | - | X | unresolved |
| 0x454510 | 0x4de150 | B | similar (0.92) calls 1.00 str 1.00 |
| 0x461a40 | 0x4ec110 | C | positional+similarity 1.00 (runner-up 0.31) |
| 0x49e860 | - | X | unresolved |
| 0x4a0690 | - | X | unresolved |
| 0x4aeff0 | - | X | unresolved |
| 0x51fea0 | 0x5bccd0 | A | identical bytes (unique) |
| 0x5399e0 | 0x5d8600 | A | identical bytes (unique) |
| 0x54d3d0 | 0x5ec650 | B | similar (0.99) calls 1.00 str 1.00 |
| 0x5b7410 | 0x63dff0 | A | identical bytes (unique) |
| 0x6782b0 | 0x77a030 | B | similar (0.92) calls 1.00 str 1.00 |
| 0x6864b0 | 0x788180 | B | similar (0.99) calls 1.00 str 0.73 |

| SD data | TW data | votes |
|---|---|---|
| 0x216b2c8 | 0x23d73c8 | 171 |
| 0x2173df0 | 0x23e0150 | 6 |
| 0x235b2f0 | 0x23f14a0 | 15 |
| 0x235c3a0 | 0x23f2510 | 182 |
| 0x235c488 | 0x23f25f8 | 96 |
| 0x235f740 | 0x23f5870 | 125 |
| 0x23b1310 | 0x2581ad0 | 3 |
| 0x24015e8 | 0x25d4a38 | 12 |
| 0x2405488 | 0x25d87f0 | 18 |
| 0x2408280 | 0x25db820 | 9 |
| 0x240bae0 | - | 0 |

## Free Cam

Game functions: 9 (A:4 B:0 C:2 X:3). Data globals: 3 (3 resolved).

| SD fn | TW fn | conf | note |
|---|---|---|---|
| 0x6ff90 | - | X | unresolved |
| 0x708d0 | - | X | unresolved |
| 0xba270 | 0xd0210 | A | identical bytes (unique) |
| 0x190ad0 | 0x1c8ae0 | A | identical bytes (unique) |
| 0x1911f0 | 0x1c94f0 | A | identical bytes (unique) |
| 0x37c560 | 0x3b34f0 | A | identical bytes (unique) |
| 0x3c84b0 | - | X | unresolved |
| 0x3ce500 | 0x407630 | C | positional+similarity 1.00 (runner-up 0.27) |
| 0x556870 | 0x5f5ab0 | C | positional+similarity 0.95 (runner-up 0.00) |

| SD data | TW data | votes |
|---|---|---|
| 0x2173df0 | 0x23e0150 | 6 |
| 0x240a0e0 | 0x25dd5b0 | 27 |
| 0x240c100 | 0x25df490 | 9 |

## Teleport / Waypoint

Game functions: 5 (A:4 B:0 C:1 X:0). Data globals: 3 (3 resolved).

| SD fn | TW fn | conf | note |
|---|---|---|---|
| 0xab970 | 0xc15e0 | A | identical bytes (unique) |
| 0xd6e30 | 0xeeae0 | A | identical bytes (unique) |
| 0xd70b0 | 0xeed60 | A | identical bytes (unique) |
| 0x190ad0 | 0x1c8ae0 | A | identical bytes (unique) |
| 0x556870 | 0x5f5ab0 | C | positional+similarity 0.95 (runner-up 0.00) |

| SD data | TW data | votes |
|---|---|---|
| 0x2174a50 | 0x23e0e40 | 18 |
| 0x235c488 | 0x23f25f8 | 96 |
| 0x24310a0 | 0x2605950 | 18 |

## Spawn Vehicle

Game functions: 17 (A:7 B:1 C:2 X:7). Data globals: 3 (3 resolved).

| SD fn | TW fn | conf | note |
|---|---|---|---|
| 0x6ee30 | 0x75c70 | B | similar (1.00) calls 1.00 str 0.00 |
| 0x176b50 | 0x1ae1b0 | C | positional+similarity 1.00 (runner-up 0.00) |
| 0x1905c0 | - | X | unresolved |
| 0x190a50 | 0x1c8a60 | A | identical bytes (unique) |
| 0x190ad0 | 0x1c8ae0 | A | identical bytes (unique) |
| 0x190c40 | 0x1c8c50 | A | identical bytes (unique) |
| 0x1e9ef0 | - | X | unresolved |
| 0x1f75f0 | - | X | unresolved |
| 0x43f280 | 0x4c81d0 | C | positional+similarity 0.96 (runner-up 0.50) |
| 0x43fbe0 | - | X | unresolved |
| 0x441910 | - | X | unresolved |
| 0x5b7410 | 0x63dff0 | A | identical bytes (unique) |
| 0x6892e0 | 0x78af90 | A | identical bytes (unique) |
| 0x68d7f0 | 0x78f370 | A | identical bytes (unique) |
| 0x68d840 | - | X | unresolved |
| 0x68e020 | 0x78fae0 | A | identical bytes (unique) |
| 0x68e350 | - | X | unresolved |

| SD data | TW data | votes |
|---|---|---|
| 0x235b2f0 | 0x23f14a0 | 15 |
| 0x235c3a0 | 0x23f2510 | 182 |
| 0x24015e8 | 0x25d4a38 | 12 |

## Spawn Custom (character)

Game functions: 0 (A:0 B:0 C:0 X:0). Data globals: 0 (0 resolved).

| SD fn | TW fn | conf | note |
|---|---|---|---|

## Spawn Object

Game functions: 14 (A:6 B:1 C:1 X:6). Data globals: 4 (3 resolved).

| SD fn | TW fn | conf | note |
|---|---|---|---|
| 0x6ee30 | 0x75c70 | B | similar (1.00) calls 1.00 str 0.00 |
| 0x1905c0 | - | X | unresolved |
| 0x190a50 | 0x1c8a60 | A | identical bytes (unique) |
| 0x190ad0 | 0x1c8ae0 | A | identical bytes (unique) |
| 0x190c40 | 0x1c8c50 | A | identical bytes (unique) |
| 0x1e9ef0 | - | X | unresolved |
| 0x1f6fb0 | - | X | unresolved |
| 0x1f8090 | - | X | unresolved |
| 0x2316d0 | 0x23e410 | A | identical bytes (unique) |
| 0x2350f0 | 0x241e30 | A | identical bytes (unique) |
| 0x43f280 | 0x4c81d0 | C | positional+similarity 0.96 (runner-up 0.50) |
| 0x43fbe0 | - | X | unresolved |
| 0x441910 | - | X | unresolved |
| 0x5b7410 | 0x63dff0 | A | identical bytes (unique) |

| SD data | TW data | votes |
|---|---|---|
| 0x2091398 | - | 0 |
| 0x216b2c8 | 0x23d73c8 | 171 |
| 0x235c3a0 | 0x23f2510 | 182 |
| 0x24015e8 | 0x25d4a38 | 12 |

## NPC Spawner

Game functions: 17 (A:8 B:1 C:1 X:7). Data globals: 13 (11 resolved).

| SD fn | TW fn | conf | note |
|---|---|---|---|
| 0x6ee30 | 0x75c70 | B | similar (1.00) calls 1.00 str 0.00 |
| 0x18a6a0 | 0x1c2150 | A | identical bytes (unique) |
| 0x1905c0 | - | X | unresolved |
| 0x190a50 | 0x1c8a60 | A | identical bytes (unique) |
| 0x190ad0 | 0x1c8ae0 | A | identical bytes (unique) |
| 0x1e9ef0 | - | X | unresolved |
| 0x1f75f0 | - | X | unresolved |
| 0x207700 | - | X | unresolved |
| 0x3694f0 | 0x3a0560 | A | identical bytes (unique) |
| 0x37c400 | 0x3b3390 | A | identical bytes (unique) |
| 0x413f20 | - | X | unresolved |
| 0x43f280 | 0x4c81d0 | C | positional+similarity 0.96 (runner-up 0.50) |
| 0x43fbe0 | - | X | unresolved |
| 0x441910 | - | X | unresolved |
| 0x46d870 | 0x4f8df0 | A | identical bytes (unique) |
| 0x5b7410 | 0x63dff0 | A | identical bytes (unique) |
| 0x64adf0 | 0x74d300 | A | identical bytes (unique) |

| SD data | TW data | votes |
|---|---|---|
| 0x207ae69 | 0x22dd2d8 | 12 |
| 0x207ae6a | 0x22dd2d9 | 3 |
| 0x2090514 | 0x22fa0ec | 6 |
| 0x2090515 | 0x22fa0ed | 6 |
| 0x2090516 | 0x22fa0ee | 6 |
| 0x235c3a0 | 0x23f2510 | 182 |
| 0x23dc610 | 0x25b21b0 | 9 |
| 0x23de286 | - | 0 |
| 0x24015e8 | 0x25d4a38 | 12 |
| 0x2401618 | 0x25d4a28 | 6 |
| 0x2405488 | 0x25d87f0 | 18 |
| 0x240eec0 | - | 0 |
| 0x2433b10 | 0x2608ba0 | 63 |