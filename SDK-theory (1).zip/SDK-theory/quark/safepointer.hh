#pragma once

namespace UFG
{
	template <typename T>
	class qSafePointerBase : public qNode<qSafePointerBase<T>>
	{
	public:
		T* m_pPointer;

		SDK_INLINE operator bool() const { return m_pPointer; }
	};

	template <typename T, typename U = T>
	class qSafePointer : public qSafePointerBase<T>
	{
	public:
		SDK_INLINE bool operator==(T* other) { return this->m_pPointer == other; }
		SDK_INLINE U* Get() { return reinterpret_cast<U*>(this->m_pPointer); }
		SDK_INLINE U* operator->() { return reinterpret_cast<U*>(this->m_pPointer); }
	};

	template <typename T>
	class qSafePointerNode
	{
	public:
		qList<qSafePointerBase<T>> m_SafePointerList;

		virtual ~qSafePointerNode() = 0;
	};

	template <typename T>
	class qSafePointerWithCallbacksBase : public qNode<qSafePointerWithCallbacksBase<T>>
	{
	public:
		T* m_pPointer;
		u32 m_Changed;
		fastdelegate::FastDelegate1<T*> m_BindCallback;
		fastdelegate::FastDelegate1<T*> m_UnbindCallback;
	};

	template <typename T, typename U = T>
	class qSafePointerWithCallbacks : public qSafePointerWithCallbacksBase<T>
	{
	public:
	};

	template <typename T>
	class qSafePointerNodeWithCallbacks : public qSafePointerNode<T>
	{
	public:
		qList<qSafePointerWithCallbacksBase<T>> m_SafePointerWithCallbackList;
	};

}